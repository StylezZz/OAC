import socket
import time

SOCK_BUFFER = 1024

if __name__ == '__main__':
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_address = ("192.168.56.1", 5000)

    print(f"Conectando a {server_address[0]}:{server_address[1]}")
    sock.connect(server_address)

    #Se enviaran mensajes solicitando resultados para cada item, siendo hora, combustible, marcas y calculos estadisticos
    msg = str(input())
    if msg == "hora":
        msg = msg.encode("utf-8")
        inicio_tx = time.perf_counter()
        sock.sendall(msg)
        fin_tx = time.perf_counter()

        amnt_recvd = 0
        amnt_expected = len(msg)
        total_data = b""

        inicio_rx = time.perf_counter()
        while amnt_recvd < amnt_expected:
            data = sock.recv(SOCK_BUFFER)
            total_data += data
            amnt_recvd += len(data)
            print(f"Recibido parcial: {data}")


    #Se envia mensaje solicitando combustible
    msg = str(input())
    if msg == "combustible":
        msg = msg.encode("utf-8")
        sock.sendall(msg)

        amnt_recvd = 0
        amnt_expected = len(msg)
        total_data = b""

        inicio_rx = time.perf_counter()
        while amnt_recvd < amnt_expected:
            data = sock.recv(SOCK_BUFFER)
            total_data += data
            amnt_recvd += len(data)
            print(f"Recibido parcial: {data}")

        fin_rx = time.perf_counter()

        
    msg = str(input())
    if msg == "marca":
        msg = msg.encode("utf-8")
        sock.sendall(msg)

        amnt_recvd = 0
        amnt_expected = len(msg)
        total_data = b""

        inicio_rx = time.perf_counter()
        while amnt_recvd < amnt_expected:
            data = sock.recv(SOCK_BUFFER)
            total_data += data
            amnt_recvd += len(data)
            print(f"Recibido parcial: {data}")

    
    msg = str(input())
    if msg == "kilometros":
        msg = msg.encode("utf-8")
        sock.sendall(msg)

        amnt_recvd = 0
        amnt_expected = len(msg)
        total_data = b""

        inicio_rx = time.perf_counter()
        while amnt_recvd < amnt_expected:
            data = sock.recv(SOCK_BUFFER)
            total_data += data
            amnt_recvd += len(data)
            print(f"Recibido parcial: {data}")

    #El cliente debe imprimir lo enviado por el servidor en terminal 
    print(f"Recibido: \n{total_data}")



    #Si es que el mensaje que se ingresa es cerrar cesion se cierra el socket
    if total_data == b'cerrar cesion':
        with ("lab_04_reporte.txt", "w") as f:
            f.write(total_data)
        sock.close()

    

