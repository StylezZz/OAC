import time
import socket
import statistics
#Variables globales
tiposCombustible = []
marcas = []
kilometrosArreglo = []

#Se debera leer el archivo Lab4_viernes.csv

def devolverDiaConMasData(linea:str)->str:
    data = linea.split(",")
    #El formato es DD/MM/AAAA HH:MM
    #De ese formato solo se requiere la hora y minutos
    nuevoArreglo = data[0].split(" ")
    fecha = nuevoArreglo[1]
    #Se separa la hora y los minutos
    #Y se retorna la hora y minutos
    return fecha


def devolverCantidadTiposDeCombustible(linea):
    data = linea.split(",")
    #Las cantidades de combustibles son variables cada linea pero siempre inician en la posicon 13
    combustibles = data[13]
    #Si es que dicho combustible no esta en la lista de combustibles
    #Se agrega a la lista de combustibles
    if combustibles not in tiposCombustible:
        tiposCombustible.append(combustibles)

    
    return len(tiposCombustible)
    
    #Luego se debera retornar cuantos autos consumen cada tipo de combustible 


def devolverCantidadMarcasYNumeroAutosPorMarca(linea):
    data = linea.split(",")
    m = data[14]
    if m not in marcas:
        marcas.append(m)
        #A su vez se debera retornar cuantas marcas de autos hay y cuantos autos hay por marca

        
def calculosEstadisticos(linea:str):
    data = linea.split(",")
    kilometros = data[11]
    kilometrosArreglo.append(int(kilometros))
    #Se debera retornar el promedio de kilometros recorridos por los autos
    sumaKilometros = 0
    for i in kilometrosArreglo:
        sumaKilometros += int(i)
    promedioKilometros = sumaKilometros / len(kilometrosArreglo)
    #Mediana de kilometros recorridos por los autos
    medianaKilometros = statistics.median(kilometrosArreglo)
    #Desviacion estandar de kilometros recorridos por los autos
    desviacionEstandarKilometros = statistics.stdev(kilometrosArreglo)
    #Moda de kilometros recorridos por los autos
    modaKilometros = statistics.mode(kilometrosArreglo)
    return [promedioKilometros,medianaKilometros,desviacionEstandarKilometros,modaKilometros]


    
    



def mainLineaPorLinea():
    idx =0

    with open("Lab4_viernes.csv","r") as f:
        while True:
            linea = f.readline()
            if not linea:
                break
            if idx == 0:
                idx += 1
                continue
            diaMasData = devolverDiaConMasData(linea)
            combustiblePedido = devolverCantidadTiposDeCombustible(linea)
            marcasPedidas = devolverCantidadMarcasYNumeroAutosPorMarca(linea)
            calculosEstadisticos(linea)
            idx += 1
            
    



if __name__ == "__main__":
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    serverAddress = ("0.0.0.0",5000)
    print(f"Iniciando servidor en {serverAddress[0]}:{serverAddress[1]}")
    sock.bind(serverAddress)

    sock.listen(5)

    while True:
        print("Esperando conexión...")
        
        connection, clientAddress = sock.accept()
        conectado = True
        print(f"Conectado a {clientAddress[0]}:{clientAddress[1]}")
        while conectado:
            data = connection.recv(1024)
            if data:
                data = data.decode("utf-8")
                mainLineaPorLinea()
                if data == "hora":
                    connection.sendall("Se ha enviado la informacion".encode("utf-8"))
                elif data == "combustible":
                    connection.sendall("Se ha enviador la informacion".encode("utf-8"))
                elif data == "marcas":
                    connection.sendall("Se ha enviado la informacion".encode("utf-8"))
                elif data == "kilometros":
                    connection.sendall("Se ha enviado la informacion".encode("utf-8"))
            if data == "cerrar sesion":
                conectado = False
                print("Sesion cerrada")
                connection.sendall("Sesion cerrada".encode("utf-8"))
                connection.close()
            

    sock.close()

    
